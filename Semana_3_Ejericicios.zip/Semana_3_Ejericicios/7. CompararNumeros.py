def MayorTres():
    frue = True
    while frue:
        try:
            a = float(input("Ingrese número 1: "))
            b = float(input("Ingrese número 2: "))
            c = float(input("Ingrese número 3: "))
            mayor = a
            if b > mayor:
                mayor = b
            if c > mayor:
                mayor = c
            print(f"El mayor es {mayor}")
            frue = False
        except:
            print("Solo puedes ingresar números.")

MayorTres()
