def Contar1a10():
    frue = True
    while frue:
        for i in range(1, 11):
            print(i)
        frue = False

Contar1a10()
