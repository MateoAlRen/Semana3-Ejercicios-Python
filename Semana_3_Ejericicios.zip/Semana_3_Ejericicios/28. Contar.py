def ContarOcurrencias():
    frue = True
    lista = []
    print("Ingresa números (o 'fin' para terminar):")
    while frue:
        entrada = input()
        if entrada.lower() == "fin":
            frue = False
        else:
            try:
                num = float(entrada)
                lista.append(num)
            except:
                print("Solo puedes ingresar números.")
    frue = True
    while frue:
        valor = input("Número a contar: ")
        try:
            vnum = float(valor)
            print(f"El número {vnum} aparece {lista.count(vnum)} veces.")
            frue = False
        except:
            print("Solo puedes ingresar números.")

ContarOcurrencias()
