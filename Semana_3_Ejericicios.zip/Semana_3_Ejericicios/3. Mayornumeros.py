def MayorDos():
    frue = True
    while frue:
        try:
            a = float(input("Ingrese número 1: "))
            b = float(input("Ingrese número 2: "))
            if a > b:
                print(f"{a} es mayor")
            elif b > a:
                print(f"{b} es mayor")
            else:
                print("Son iguales")
            frue = False
        except:
            print("Solo puedes ingresar números.")

MayorDos()
