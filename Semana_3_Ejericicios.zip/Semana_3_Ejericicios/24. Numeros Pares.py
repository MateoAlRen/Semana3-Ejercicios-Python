def NumerosPares():
    frue = True
    lista = []
    print("Ingresa números (o 'fin' para terminar):")
    while frue:
        entrada = input()
        if entrada.lower() == "fin":
            frue = False
        else:
            try:
                num = int(entrada)
                lista.append(num)
            except:
                print("Solo puedes ingresar números enteros.")
    pares = [x for x in lista if x % 2 == 0]
    print("Números pares:", pares)

NumerosPares()
