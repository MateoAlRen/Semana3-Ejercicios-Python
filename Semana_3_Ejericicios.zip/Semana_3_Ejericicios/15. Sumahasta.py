def SumaHasta():
    frue = True
    while frue:
        try:
            n = int(input("Ingrese un número entero: "))
            if n > 0:
                suma = 0
                i = 1
                while i <= n:
                    suma += i
                    i += 1
                print("Suma:", suma)
                frue = False
            else:
                print("Número positivo por favor.")
        except:
            print("Solo puedes ingresar números enteros.")

SumaHasta()
