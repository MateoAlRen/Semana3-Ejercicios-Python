def Calculadora():
    frue = True
    while frue:
        try:
            a = float(input("Ingrese número 1: "))
            b = float(input("Ingrese número 2: "))
            op = input("Ingrese operador (+, -, *, /): ")
            if op == "+":
                print("Resultado:", a + b)
                frue = False
            elif op == "-":
                print("Resultado:", a - b)
                frue = False
            elif op == "*":
                print("Resultado:", a * b)
                frue = False
            elif op == "/":
                if b == 0:
                    print("No se puede dividir entre cero.")
                else:
                    print("Resultado:", a / b)
                    frue = False
            else:
                print("Operador no válido.")
        except:
            print("Solo puedes ingresar números.")

Calculadora()
