def SumarElementos():
    frue = True
    lista = []
    while frue:
        entrada = input("Ingresa un número (o 'fin' para terminar): ")
        if entrada.lower() == "fin":
            frue = False
        else:
            try:
                num = float(entrada)
                lista.append(num)
            except:
                print("Solo puedes ingresar números.")
    print("Suma total:", sum(lista))

SumarElementos()
