import time

def CuentaRegresiva():
    frue = True
    while frue:
        try:
            n = int(input("Desde qué número quieres la cuenta regresiva?: "))
            if n > 0:
                while n > 0:
                    print(n)
                    time.sleep(1)  # pausa de 1 segundo
                    n -= 1
                print("¡Tiempo!")
                frue = False
            else:
                print("Número positivo por favor.")
        except:
            print("Solo puedes ingresar números enteros.")

CuentaRegresiva()
