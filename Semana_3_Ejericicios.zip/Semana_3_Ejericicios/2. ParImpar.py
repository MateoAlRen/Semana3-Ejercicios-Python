def ParImpar():
    frue = True
    while frue:
        try:
            n = int(input("Ingrese un número entero: "))
            if n % 2 == 0:
                print("Par")
            else:
                print("Impar")
            frue = False
        except:
            print("Solo puedes ingresar números enteros.")

ParImpar()
