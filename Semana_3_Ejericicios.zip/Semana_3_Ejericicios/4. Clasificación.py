def ClasificarEdad():
    frue = True
    while frue:
        try:
            edad = int(input("Ingrese edad: "))
            if edad < 0:
                print("Edad no válida.")
            elif edad <= 12:
                print("Niño")
            elif edad <= 17:
                print("Adolescente")
            elif edad <= 59:
                print("Adulto")
            else:
                print("Anciano")
            frue = False
        except:
            print("Solo puedes ingresar números enteros.")

ClasificarEdad()
