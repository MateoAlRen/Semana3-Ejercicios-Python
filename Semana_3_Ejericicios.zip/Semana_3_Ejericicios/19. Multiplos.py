def Multiplos3():
    frue = True
    while frue:
        for i in range(1, 101):
            if i % 3 == 0:
                print(i)
        frue = False

Multiplos3()
