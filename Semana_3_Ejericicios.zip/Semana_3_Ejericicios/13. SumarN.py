def SumarN():
    frue = True
    while frue:
        try:
            n = int(input("Ingrese un número entero: "))
            if n > 0:
                suma = 0
                for i in range(1, n + 1):
                    suma += i
                print("Suma:", suma)
                frue = False
            else:
                print("Número positivo por favor.")
        except:
            print("Solo puedes ingresar números enteros.")

SumarN()
