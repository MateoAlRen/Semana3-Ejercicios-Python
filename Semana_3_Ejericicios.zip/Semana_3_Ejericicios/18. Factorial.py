def Factorial():
    frue = True
    while frue:
        try:
            n = int(input("Ingrese un número entero >=0: "))
            if n >= 0:
                fact = 1
                for i in range(1, n + 1):
                    fact *= i
                print(f"Factorial de {n} es {fact}")
                frue = False
            else:
                print("Número no negativo por favor.")
        except:
            print("Solo puedes ingresar números enteros.")

Factorial()
