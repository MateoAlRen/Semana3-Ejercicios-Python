def TablaMultiplicar():
    frue = True
    while frue:
        try:
            n = int(input("Ingrese un número entero: "))
            for i in range(1, 11):
                print(f"{n} x {i} = {n*i}")
            frue = False
        except:
            print("Solo puedes ingresar números enteros.")

TablaMultiplicar()
