def PositivoNegativo():
    frue = True
    while frue:
        try:
            n = float(input("Ingrese un número: "))
            if n > 0:
                print("Positivo")
            elif n < 0:
                print("Negativo")
            else:
                print("Cero")
            frue = False
        except:
            print("Solo puedes ingresar números.")

PositivoNegativo()
