def NumeroSecreto():
    frue = True
    secreto = 7
    print("Adivina el número secreto (1 a 10).")
    while frue:
        try:
            n = int(input("Número: "))
            if n < secreto:
                print("Muy bajo.")
            elif n > secreto:
                print("Muy alto.")
            else:
                print("¡Correcto!")
                frue = False
        except:
            print("Solo puedes ingresar números enteros.")

NumeroSecreto()
