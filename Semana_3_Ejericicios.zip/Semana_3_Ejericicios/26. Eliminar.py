def EliminarDuplicados():
    frue = True
    lista = []
    print("Ingresa números (o 'fin' para terminar):")
    while frue:
        entrada = input()
        if entrada.lower() == "fin":
            frue = False
        else:
            try:
                num = float(entrada)
                lista.append(num)
            except:
                print("Solo puedes ingresar números.")
    lista_sin_duplicados = list(dict.fromkeys(lista))
    print("Lista sin duplicados:", lista_sin_duplicados)

EliminarDuplicados()
