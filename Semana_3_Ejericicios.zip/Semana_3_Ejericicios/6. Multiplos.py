def Multiplo35():
    frue = True
    while frue:
        try:
            n = int(input("Ingrese un número entero: "))
            if n % 3 == 0 and n % 5 == 0:
                print("Múltiplo de 3 y 5")
            elif n % 3 == 0:
                print("Múltiplo de 3")
            elif n % 5 == 0:
                print("Múltiplo de 5")
            else:
                print("No es múltiplo de 3 ni de 5")
            frue = False
        except:
            print("Solo puedes ingresar números enteros.")

Multiplo35()
