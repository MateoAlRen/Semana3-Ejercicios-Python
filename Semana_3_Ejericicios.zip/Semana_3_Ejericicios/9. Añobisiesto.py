def AñoBisiesto():
    frue = True
    while frue:
        try:
            año = int(input("Ingrese un año: "))
            if (año % 400 == 0) or (año % 4 == 0 and año % 100 != 0):
                print("Es bisiesto")
            else:
                print("No es bisiesto")
            frue = False
        except:
            print("Solo peudes ingresar números enteros.")

AñoBisiesto()
