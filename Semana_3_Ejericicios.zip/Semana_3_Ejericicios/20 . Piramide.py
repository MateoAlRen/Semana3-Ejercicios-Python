def Piramide():
    frue = True
    while frue:
        try:
            n = int(input("Altura de la pirámide: "))
            if n > 0:
                for i in range(1, n + 1):
                    print(" " * (n - i) + "*" * (2*i - 1))
                frue = False
            else:
                print("Número positivo por favor.")
        except:
            print("Solo puedes ingresar números enteros.")

Piramide()
