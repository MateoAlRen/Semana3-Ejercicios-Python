def BuscarElemento():
    frue = True
    lista = []
    print("Ingresa números para la lista (o 'fin' para terminar):")
    while frue:
        entrada = input()
        if entrada.lower() == "fin":
            frue = False
        else:
            try:
                num = float(entrada)
                lista.append(num)
            except:
                print("Solo puedes ingresar números.")
    frue = True
    while frue:
        buscar = input("Número a buscar: ")
        try:
            bnum = float(buscar)
            if bnum in lista:
                print("Está en la lista.")
            else:
                print("No está en la lista.")
            frue = False
        except:
            print("Solo puedes ingresar números.")

BuscarElemento()
