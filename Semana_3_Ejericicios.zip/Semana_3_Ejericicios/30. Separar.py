def SepararParesImpares():
    frue = True
    lista = []
    print("Ingresa números enteros (o 'fin' para terminar):")
    while frue:
        entrada = input()
        if entrada.lower() == "fin":
            frue = False
        else:
            try:
                num = int(entrada)
                lista.append(num)
            except:
                print("Solo puedes ingresar números enteros.")
    pares = [x for x in lista if x % 2 == 0]
    impares = [x for x in lista if x % 2 != 0]
    print("Pares:", pares)
    print("Impares:", impares)

SepararParesImpares()
