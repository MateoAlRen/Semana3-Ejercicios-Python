def PromedioCalificaciones():
    frue = True
    lista = []
    while frue:
        entrada = input("Ingresa calificación (o 'fin' para terminar): ")
        if entrada.lower() == "fin":
            if len(lista) > 0:
                promedio = sum(lista) / len(lista)
                print("Promedio:", round(promedio, 2))
                frue = False
            else:
                print("No ingresaste calificaciones.")
        else:
            try:
                cal = float(entrada)
                if 0 <= cal <= 10:
                    lista.append(cal)
                else:
                    print("Calificación entre 0 y 10.")
            except:
                print("Solo puedes ingresar números.")

PromedioCalificaciones()
