def AproRepro():
    frue = True
    while frue:
        try:
            cal = float(input("Ingrese calificación (0-10): "))
            if 0 <= cal <= 10:
                if cal >= 6:
                    print("Aprobado")
                else:
                    print("Reprobado")
                frue = False
            else:
                print("Debe estar entre 0 y 10.")
        except:
            print("Solo podemos ingresar números.")

AproRepro()
