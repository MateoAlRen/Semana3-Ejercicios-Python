def ValidarContrasena():
    frue = True
    clave_esperada = "pepe23"
    while frue:
        clave = input("Ingrese la contraseña: ")
        if clave == clave_esperada:
            print("Contraseña correcta")
            frue = False
        else:
            print("Contraseña incorrecta")

ValidarContrasena()
