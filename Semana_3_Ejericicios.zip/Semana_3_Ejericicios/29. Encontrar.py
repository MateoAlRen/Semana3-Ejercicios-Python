def MayorYMenor():
    frue = True
    lista = []
    print("Ingresa números (o 'fin' para terminar):")
    while frue:
        entrada = input()
        if entrada.lower() == "fin":
            if len(lista) > 0:
                print("Mayor:", max(lista))
                print("Menor:", min(lista))
                frue = False
            else:
                print("No ingresaste números.")
        else:
            try:
                num = float(entrada)
                lista.append(num)
            except:
                print("Solo puedes ingresar números.")

MayorYMenor()
