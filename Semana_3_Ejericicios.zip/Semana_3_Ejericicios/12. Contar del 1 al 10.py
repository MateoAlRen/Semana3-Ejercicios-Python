def ContadorDesc():
    frue = True
    while frue:
        i = 10
        while i > 0:
            print(i)
            i -= 1
        frue = False

ContadorDesc()
